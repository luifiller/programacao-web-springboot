package sptech.school.validacoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidacoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidacoesApplication.class, args);
	}

}
