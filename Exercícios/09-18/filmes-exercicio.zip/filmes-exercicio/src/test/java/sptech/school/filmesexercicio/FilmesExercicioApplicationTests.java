package sptech.school.filmesexercicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmesExercicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
