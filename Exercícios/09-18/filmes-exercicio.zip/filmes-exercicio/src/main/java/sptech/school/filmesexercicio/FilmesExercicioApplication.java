package sptech.school.filmesexercicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmesExercicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmesExercicioApplication.class, args);
	}

}
