package school.sptech.marketplaceresumido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketplaceResumidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarketplaceResumidoApplication.class, args);
	}

}
