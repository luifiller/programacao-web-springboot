package school.sptech.marketplaceresumido.service.produto;

import org.springframework.stereotype.Service;

@Service
public class ProdutoService {

}
