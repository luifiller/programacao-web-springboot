package exercicio.preparacaoprova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreparacaoProvaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreparacaoProvaApplication.class, args);
	}

}
