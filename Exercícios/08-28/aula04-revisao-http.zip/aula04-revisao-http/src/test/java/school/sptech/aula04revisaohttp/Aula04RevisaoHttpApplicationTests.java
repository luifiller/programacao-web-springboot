package school.sptech.aula04revisaohttp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula04RevisaoHttpApplicationTests {

	@Test
	void contextLoads() {
	}

}
