package school.sptech.aula04revisaohttp;

public class Heroi {

  private String nome;
  private String habilidade;
  private int idade;
  private int forca;
  private boolean vivo = true;

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getHabilidade() {
    return habilidade;
  }

  public void setHabilidade(String habilidade) {
    this.habilidade = habilidade;
  }

  public int getIdade() {
    return idade;
  }

  public void setIdade(int idade) {
    this.idade = idade;
  }

  public int getForca() {
    return forca;
  }

  public void setForca(int forca) {
    this.forca = forca;
  }

  public boolean isVivo() {
    return vivo;
  }
}
