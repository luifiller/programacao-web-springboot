package school.sptech.aula04revisaohttp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula04RevisaoHttpApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula04RevisaoHttpApplication.class, args);
	}

}
