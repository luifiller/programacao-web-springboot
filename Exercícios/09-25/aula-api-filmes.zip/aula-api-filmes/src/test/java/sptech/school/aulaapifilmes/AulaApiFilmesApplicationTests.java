package sptech.school.aulaapifilmes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaApiFilmesApplicationTests {

	@Test
	void contextLoads() {
	}

}
