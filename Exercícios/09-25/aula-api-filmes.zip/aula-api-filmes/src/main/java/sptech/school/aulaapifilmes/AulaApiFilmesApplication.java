package sptech.school.aulaapifilmes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaApiFilmesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaApiFilmesApplication.class, args);
	}

}
