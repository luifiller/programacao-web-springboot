package school.sptech.atividade1.controller.dto;

import lombok.Data;

@Data
public class UsuarioSimpleResponse {
    private Integer id;
    private String nomeCompleto;
}
