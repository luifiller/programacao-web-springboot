package sptech.school.estoquespringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstoqueSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstoqueSpringbootApplication.class, args);
	}

}
