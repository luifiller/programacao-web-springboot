package sptech.school.estoquespringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
