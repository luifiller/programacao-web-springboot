package school.sptech.avaliacaocontinuada2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvaliacaoContinuada2Application {

	/*
		Não altere esta classe!!!

		Isso pode impactar sua nota!
		Foque seus esforços no REPOSITORY e CONTROLLER DE PRODUCAO
	*/

	public static void main(String[] args) {
		SpringApplication.run(AvaliacaoContinuada2Application.class, args);
	}

}
