package school.sptech.avaliacaocontinuada2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import school.sptech.avaliacaocontinuada2.entity.Producao;

    /*
        Precisamos da sua ajuda aqui!
        Escreva os métodos abaixo:
    */

public interface ProducaoRepository extends JpaRepository<Producao, Integer> {

    //1. Buscar producoes por nome do diretor (VALOR EXATO):

    // 2. Buscar producoes por parte do titulo (VALOR APROXIMADO ignorando maiusculas e minusculas):

    //3. Contar todas as producoes de um genero (VALOR EXATO):

    //4. Buscar producoes com data de lançamento MAIOR que uma data específica:

    //5. Buscar producoes com data de lançamento MENOR OU IGUAL que uma data específica:

    //6. Buscar producao mais votada (maior quantidade de avaliacoes):

    //7. Buscar top 3 producoes com maior nota (SOMENTE 3, sendo a primeira a maior):
}
